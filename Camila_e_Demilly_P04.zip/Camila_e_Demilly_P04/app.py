# O código foi reaproveitado de uma atividade anterior em grupo
# Discentes: Demilly L. Gonçalves de Medeiros e Camila Thaís Silva Medeiros

from flask import Flask, render_template, request, redirect, make_response, url_for, session, flash
# from flask_session import Session
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

class Usuario(UserMixin):
    def __init__(self, nome):
        self.id = nome

app = Flask(__name__)
app.config['SECRET_KEY'] = 'MEGADIFICIL_ME_ESCONDE'

login_manager = LoginManager(app)
login_manager.login_view = 'login' # type: ignore

# Função que carrega o usuário logado (obrigatória!)
@login_manager.user_loader
def load_user(user_id):
    if user_id in usuarios:
        return Usuario(user_id)
    return None

# Armazena o usuário e a senha em um dicionário
usuarios = {}
lista_produtos = [
    {'id': 1, 'nome': 'Senhor dos Anéis', 'preco': 35},
    {'id': 2, 'nome': 'Harry Potter', 'preco': 35},
    {'id': 3, 'nome': 'Nárnia', 'preco': 20},
    {'id': 4, 'nome': 'Sherlock Holmes', 'preco': 25}
] 

# Rota para a página inicial
@app.route('/')
def index():
    nome_usuario = request.cookies.get("nome")
    return render_template('index.html', nome=nome_usuario)

# Rota para a página de cadastro
@app.route('/cadastro', methods=['POST', 'GET'])
def cadastro():
    if request.method == 'POST':
        nome = request.form.get('nome') or ''
        senha = request.form.get('senha') or ''

        senha_criptografada = generate_password_hash(senha)

        if nome not in usuarios:         
            usuarios[nome] = {
                'senha': senha_criptografada,
                'carrinho': []}
            print('\nDICIONÁRIO DOS USUÁRIOS:', usuarios, '\n')
            flash("Cadastro realizado com sucesso!")
            return redirect(url_for('login'))
        
        elif nome in usuarios and check_password_hash(usuarios[nome]['senha'], senha):
            flash("Você já está cadastrado")
            return redirect(url_for('login'))

    return render_template('cadastro.html')

# Rota para a página de login 
@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        nome = request.form.get('nome') or ''
        senha = request.form.get('senha') or ''

        if nome not in usuarios:
            return redirect(url_for('cadastro'))
        
        elif nome in usuarios and check_password_hash(usuarios[nome]['senha'], senha):
            usuario = Usuario(nome)
            login_user(usuario)
            resp = make_response(redirect(url_for('produtos')))
            resp.set_cookie("nome", nome)
            return resp
        else:
            flash('Senha incorreta. Tente novamente.')
            return redirect(url_for('login'))

    return render_template('login.html')

# Rota para a página de logout
@app.route('/logout', methods=["POST", "GET"])
def logout():
    logout_user()
    return redirect(url_for('index'))

# Rota para a página de produtos
@app.route('/produtos', methods=["GET", "POST"])
@login_required
def produtos():
    if request.method == 'POST':
        # getlist -- pega vários valores dos produtos selecionados com o mesmo nome 'produto_id' no formulário HTML
        selecionados = request.form.getlist('produto_id')
        selecionados_convertidos = []

        # Converte para uma lista de inteiros
        for id in selecionados:
            numero = int(id)
            selecionados_convertidos.append(numero)
        print('\nPRODUTOS SELECIONADOS:', selecionados_convertidos, '\n')

        usuarios[current_user.id]['carrinho'].extend(selecionados_convertidos)

        return redirect(url_for('carrinho'))
    return render_template('produtos.html', produtos=lista_produtos)

# Rota para a página de carrinho
@app.route('/carrinho')
@login_required
def carrinho():
    carrinho_ids = usuarios[current_user.id].get('carrinho', [])
    itens = {}
    for produto in lista_produtos:
        if produto["id"] in carrinho_ids:
            itens[produto["id"]] = {
                'nome': produto["nome"],
                'preco': produto["preco"]
            }

    return render_template('carrinho.html', itens=itens)

@app.route('/remover/<int:produto_id>', methods=['POST'])
@login_required
def remover(produto_id):
    carrinho = usuarios[current_user.id].get('carrinho', [])

    if produto_id in carrinho:
        carrinho.remove(produto_id)

    return redirect(url_for('carrinho'))

if __name__ == "__main__":
    app.run(debug=True)
